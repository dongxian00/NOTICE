from aliyunsdkiot.request.v20180120 import QueryDeviceDetailRequest
from aliyunsdkcore import client
import json
import subprocess
class OTA_Tools:
    def createClient():
        accessKeyId = 'LTAIiOoq6G6XK0xH'
        accessKeySecret = 'XbO7qrFPnRuaW9c0kT24mzh1qgQtXV'
        regionId = 'cn-shanghai'
        clt = client.AcsClient(accessKeyId, accessKeySecret, regionId)
        return clt
    clt = createClient()
    def queryDeviceByName(self, productKey, deviceName):
        request = QueryDeviceDetailRequest.QueryDeviceDetailRequest()
        request.set_ProductKey(productKey)
        request.set_DeviceName(deviceName)
        result = str(self.clt.do_action_with_exception(request),'utf-8')
        result_json = json.JSONDecoder().decode(result)
        if result_json['Success']:
            return result_json['Data']
        else:
            print('queryDeviceByName failed , errorMessage=' + result_json['ErrorMessage'] + ', requestId=' + result_json['RequestId'])

    def getDeviceList(self,path):
        deviceList = []
        with open(path) as f:
            line = f.readline().strip()
            while len(line) > 0:
                deviceList.append(line)
                line = f.readline().strip()
        return deviceList

if __name__=="__main__":
    tool = OTA_Tools()
    productkey="a1hBht2FlUT"
    deviceList=tool.getDeviceList("devices.txt")
    try:
        success = 0
        for deviceName in deviceList:
            info = tool.queryDeviceByName(productkey,deviceName)
            if info['FirmwareVersion'] == '20190920_000619':
                success = success + 1
        rate = success/len(deviceList)
        mes = '自9月20日22点推送619版本给入户设备，截至当前OTA成功率为'+ str(success) + '/' + str(len(deviceList)) + '=' + str('%.2f%%' % (rate * 100)) + '；提前祝大家国庆节快乐'
        subprocess.call('curl -X POST \
                  https://rocket.bytedance.net/v2/larkatmembersingroup \
                  -F "msg="' + mes +' \
                  -F infotype=3 \
                  -F groupid=6702294684854665485 \
                  -F bottype=0', shell=True)
    except:
        pass



