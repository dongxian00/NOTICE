#!/usr/bin/python
# -*- coding: utf-8 -*-
import json
from Common.ClientUtil import ClientUtil
from Common.ServiceUtil import ServiceUtil
from aliyunsdkiot.request.v20180120 import DeleteDeviceRequest
from aliyunsdkiot.request.v20180120 import QueryBatchRegisterDeviceStatusRequest
from aliyunsdkiot.request.v20180120 import BatchCheckDeviceNamesRequest;
from aliyunsdkiot.request.v20180120 import BatchRegisterDeviceWithApplyIdRequest
from aliyunsdkiot.request.v20180120 import QueryDeviceRequest
from aliyunsdkiot.request.v20180120 import QueryDeviceDetailRequest
from aliyunsdkiot.request.v20180120 import QueryPageByApplyIdRequest
from aliyunsdkiot.request.v20180120 import CreateDeviceGroupRequest
from aliyunsdkiot.request.v20180120 import QueryDeviceGroupListRequest
from aliyunsdkiot.request.v20180120 import BatchAddDeviceGroupRelationsRequest
from aliyunsdkiot.request.v20180120 import QueryDeviceListByDeviceGroupRequest
from aliyunsdkiot.request.v20180120 import BatchDeleteDeviceGroupRelationsRequest
from aliyunsdkiot.request.v20180120 import DeleteDeviceGroupRequest
class OTA_Tools:
    clt = ClientUtil.createClient()
    # 按批次号查看设备信息
    def QueryDevicesByApplyId(self,applyId):
        request = QueryPageByApplyIdRequest.QueryPageByApplyIdRequest()
        request.set_ApplyId(applyId)
        request.set_PageSize(50)
        request.set_CurrentPage(0)
        result = str(self.clt.do_action_with_exception(request),'utf-8')
        result_json = json.JSONDecoder().decode(result)
        print(result_json)
        if result_json['Success'] is None:
            print('QueryPageByApplyIdRequest failed , errorMessage=' + result_json['ErrorMessage'] + ', requestId=' + result_json[
                'RequestId'])
            return
        devices = result_json['ApplyDeviceList']
        for device in devices:
            print("#####",device)

    # 注册设备，返回批次号
    def registerDevicesByNames(self, productKey, deviceNames):
        total=len(deviceNames)
        request = BatchCheckDeviceNamesRequest.BatchCheckDeviceNamesRequest()
        request.set_ProductKey(productKey)
        request.set_DeviceNames(deviceNames)
        result=str(self.clt.do_action_with_exception(request),'utf-8')
        result_json=json.JSONDecoder().decode(result)
        print(result_json)
        if result_json['Success'] is None:
            print('BatchCheckDeviceNamesRequest failed , errorMessage=' + result_json[
                'ErrorMessage'] + ', requestId=' +
                  result_json['RequestId'])
            return None
        applyId = result_json['Data']["ApplyId"]

        request = QueryBatchRegisterDeviceStatusRequest.QueryBatchRegisterDeviceStatusRequest()
        request.set_ProductKey(productKey)
        request.set_ApplyId(applyId)
        result_json = json.JSONDecoder().decode(result)
        print(result_json)
        if not result_json['Success']:
            print('QueryBatchRegisterDeviceStatusRequest failed , errorMessage=' + result_json[
                'ErrorMessage'] + ', requestId=' +
                  result_json['RequestId'])
            return None

        request = BatchRegisterDeviceWithApplyIdRequest.BatchRegisterDeviceWithApplyIdRequest()
        request.set_ProductKey(productKey)
        request.set_ApplyId(applyId)
        result = str(self.clt.do_action_with_exception(request),'utf-8')
        result_json = json.JSONDecoder().decode(result)
        print(result_json)
        if not result_json['Success']:
            print('BatchRegisterDeviceWithApplyIdRequest failed , errorMessage=' + result_json['ErrorMessage'] + ', requestId=' +
                  result_json['RequestId'])

        page = 0

        # while True:
        #     request = QueryPageByApplyIdRequest.QueryPageByApplyIdRequest()
        #     request.set_ApplyId(applyId)
        #     request.set_PageSize(50)
        #     request.set_CurrentPage(page)
        #     result = str(self.clt.do_action_with_exception(request),'utf-8')
        #     result_json = json.JSONDecoder().decode(result)
        #     print(result_json)
        #     if not result_json['Success']:
        #         print('QueryPageByApplyIdRequest failed , errorMessage=' + result_json['ErrorMessage'] + ', requestId=' +
        #               result_json[
        #                   'RequestId'])
        #         break
        #     devices = result_json['ApplyDeviceList']
        #     for device in devices:
        #         print("#####", device)
        #
        #     if (page+1)*50>=total:
        #         break
        #     page=page+1
        return applyId

    # 按组名建立设备分组
    def createDeviceGroup(self,groupName,applyId):
        request = CreateDeviceGroupRequest.CreateDeviceGroupRequest()
        request.set_GroupName(groupName)
        request.set_GroupDesc(applyId)
        result = str(self.clt.do_action_with_exception(request),'utf-8')
        result_json = json.JSONDecoder().decode(result)
        print(result_json)
        if not result_json['Success']:
            print(
                'CreateDeviceGroupRequest failed , errorMessage=' + result_json['ErrorMessage'] + ', requestId=' + result_json[
                    'RequestId'])
            return None
        return result_json["Data"]["GroupId"]

    # 按组名获取组ID
    def getGroupId(self,groupName):
        request = QueryDeviceGroupListRequest.QueryDeviceGroupListRequest()
        request.set_GroupName(groupName)
        result = str(self.clt.do_action_with_exception(request),'utf-8')
        result_json = json.JSONDecoder().decode(result)
        print(result_json)
        if not result_json['Success']:
            print(
                'QueryDeviceGroupListRequest failed , errorMessage=' + result_json['ErrorMessage'] + ', requestId=' + result_json[
                    'RequestId'])
            return None
        groupInfo = result_json['Data']['GroupInfo']
        return groupInfo[0]['GroupId']

    # 将设备添加到指定分组
    def addDeviceToDeviceGroup(self,groupid,productKey,deviceNames):
        request = BatchAddDeviceGroupRelationsRequest.BatchAddDeviceGroupRelationsRequest()
        request.set_GroupId(groupid)
        devices = []
        for deviceName in deviceNames:
            device={}
            device["ProductKey"]=productKey
            device["DeviceName"]=deviceName
            devices.append(device)
        request.set_Devices(devices)
        result = str(self.clt.do_action_with_exception(request),'utf-8')
        result_json = json.JSONDecoder().decode(result)
        print(result_json)
        if result_json['Success'] == False:
            print(
                'BatchAddDeviceGroupRelationsRequest failed , errorMessage=' + result_json['ErrorMessage'] + ', requestId=' + result_json[
                    'RequestId'])
            return None

        return "addDeviceToDeviceGroup OK"

    def queryDeviceListByGroupId(self,groupId):
        request = QueryDeviceListByDeviceGroupRequest.QueryDeviceListByDeviceGroupRequest()
        request.set_GroupId(groupId)
        page=1
        request.set_PageSize(50)
        devicesInfo=[]
        while True:
            request.set_CurrentPage(page)
            result = str(self.clt.do_action_with_exception(request),'utf-8')
            result_json = json.JSONDecoder().decode(result)
            print(result_json)
            if not result_json['Success']:
                print(
                    'QueryDeviceListByDeviceGroupRequest failed , errorMessage=' + result_json['ErrorMessage'] + ', requestId=' + result_json[
                        'RequestId'])
                return None
            devicesInfo.extend(result_json['Data']['SimpleDeviceInfo'])
            total = result_json['Total']
            if page*50>=total:
                break
            page=page+1
        return devicesInfo
    def batchDeleteDeviceInGroup(self,groupId,devices):
        request = BatchDeleteDeviceGroupRelationsRequest.BatchDeleteDeviceGroupRelationsRequest()
        request.set_GroupId(groupId)
        request.set_Devices(devices)
        result = str(self.clt.do_action_with_exception(request),'utf-8')
        result_json = json.JSONDecoder().decode(result)
        print(result_json)
        if not result_json['Success']:
            print(
                'BatchDeleteDeviceGroupRelationsRequest failed , errorMessage=' + result_json[
                    'ErrorMessage'] + ', requestId=' + result_json[
                    'RequestId'])
            return None
        return "batchDeleteDeviceInGroup OK"
    def deleteGroup(self,groupId):
        request = DeleteDeviceGroupRequest.DeleteDeviceGroupRequest()
        request.set_GroupId(groupId)
        result = str(self.clt.do_action_with_exception(request),'utf-8')
        result_json = json.JSONDecoder().decode(result)
        print(result_json)
        if not result_json['Success']:
            print(
                'batchDeleteGroup failed , errorMessage=' + result_json[
                    'ErrorMessage'] + ', requestId=' + result_json[
                    'RequestId'])
            return None
        return "batchDeleteGroup OK"

    # 查看指定设备信息
    def queryDeviceByName(self, productKey, deviceName):
        request = QueryDeviceDetailRequest.QueryDeviceDetailRequest()
        request.set_ProductKey(productKey)
        request.set_DeviceName(deviceName)
        result = str(self.clt.do_action_with_exception(request),'utf-8')
        result_json = json.JSONDecoder().decode(result)
        #print(result_json)
        if result_json['Success']:
            return result_json['Data']
            #print('queryDeviceByName success ', result)
        else:
            print(
                'queryDeviceByName failed , errorMessage=' + result_json['ErrorMessage'] + ', requestId=' + result_json[
                    'RequestId'])

    # 查看指定产品所有设备信息
    def queryDevicesByProductKey(self, productKey,page):
        request = QueryDeviceRequest.QueryDeviceRequest()
        request.set_ProductKey(productKey)
        request.set_PageSize(50)
        request.set_CurrentPage(page)
        result = str(self.clt.do_action_with_exception(request),'utf-8')
        result_json = json.JSONDecoder().decode(result)
        #print(result_json)
        if result_json['Success']:
            #print('queryDevice success ', result)
            if "Data" in result_json:
                return result_json["Data"]["DeviceInfo"]
        else:
            print('queryDevice failed , errorMessage=' + result_json['ErrorMessage'] + ', requestId=' + result_json[
                'RequestId'])
            return None

    # 删除指定设备
    def deleteDevice(self,product_key,name):
        request = DeleteDeviceRequest.DeleteDeviceRequest()
        request.set_ProductKey(product_key)
        request.set_DeviceName(name)
        result = str(self.clt.do_action_with_exception(request),'utf-8')
        result_json = json.JSONDecoder().decode(result)
        print(result_json)
        if not result_json['Success']:
            print('queryDevice failed , errorMessage=' + result_json['ErrorMessage'] + ', requestId=' + result_json[
                'RequestId'])
            return ""
        return name

def batchRegisterDevice(productKey,groupName,deviceNames):
    tool = OTA_Tools()
    applyId = tool.registerDevicesByNames(productKey, deviceNames)
    if applyId is None:
        print("register Devices Fail")
        return None
    print("Create Group for AppId:",applyId)
    groupdId = tool.createDeviceGroup(groupName,applyId)
    if groupdId is None:
        print("Create Group Fail")
        return None
    print("addDeviceToDeviceGroup")
    ret = tool.addDeviceToDeviceGroup(groupdId,productKey,deviceNames)
    if ret is None:
        print("Add Device To Group Fail")
        return None;
    return "batchRegisterDevice OK"

def batchDeleteDevice(groupName):
    tool = OTA_Tools()
    groupId=tool.getGroupId(groupName)
    if groupId is None:
        print("batchDeleteDevice fail")
        return None
    print("groupid",groupId)

    deviceInfoList = tool.queryDeviceListByGroupId(groupId)
    if deviceInfoList is None:
        print("queryDeviceListByGroupId fail")
        return None

    devices=[]
    for deviceInfo in deviceInfoList:
        device={}
        device["ProductKey"]=deviceInfo['ProductKey']
        device['DeviceName']=deviceInfo['DeviceName']
        devices.append(device)
    print("remove devices outof group")
    print(devices)

    ret = tool.batchDeleteDeviceInGroup(groupId,devices)
    if ret is None:
        print("batchDeleteDeviceInGroup Fail")
        return None
    print("Delete Devices")
    for device in devices:
        print("Delete Device",device['ProductKey'],device['DeviceName'])
        tool.deleteDevice(device['ProductKey'],device['DeviceName'])

    ret = tool.deleteGroup(groupId)
    if ret is None:
        print("deleteGroup Fail")
        return None
    return "batchDeleteDevice OK"


