from linkkit import linkkit
from ali_ota_tool import OTA_Tools

def on_device_dynamic_register(rc, value, userdata):
    if rc == 0:
        print("dynamic register device success, rc:%d, value:%s" % (rc, value))
    else:
        print("dynamic register device fail,rc:%d, value:%s" % (rc, value))

def publish_version(lk,productKey,deviceName):
    #print("####Publish Version")
    rc, mid = lk.publish_topic(lk.to_full_topic("/ota/device/inform/%s/%s" % (productKey,deviceName)),
                               '''
                           {
                             "id": 1,
                             "params": {
                               "version": "20190802_388"
                             }
                           }
                           ''')
def subscribe_upgrade(lk,productKey,deviceName):
    #print("####SubScribe Upgrade")
    rc, mid = lk.subscribe_topic("/ota/device/upgrade/%s/%s" % (productKey,deviceName))

def publish_progress(lk,productKey,deviceName):
    #print("####Publish Progress")
    rc, mid = lk.publish_topic("/ota/device/progress/%s/%s" % (productKey,deviceName),
                               '''
{
  "id": 1,
  "params": {
    "step":"1", 
    "desc":" xxxxxxxx "
  }   
}
                               ''')
def on_connect(session_flag, rc, userdata):
    print("on_connect:%d,rc:%d" % (session_flag, rc),"userdata",userdata)


def on_disconnect(rc, userdata):
    print("on_disconnect:rc:%d" % rc,"userdata:",userdata)


def on_topic_message(topic, payload, qos, userdata):
    print("on_topic_message:" + topic + " payload:" + str(payload) + " qos:" + str(qos),"userdata",userdata)


def on_subscribe_topic(mid, granted_qos, userdata):
    print("on_subscribe_topic mid:%d, granted_qos:%s" %
          (mid, str(','.join('%s' % it for it in granted_qos))),"userdata",userdata)
    pass


def on_unsubscribe_topic(mid, userdata):
    print("on_unsubscribe_topic mid:%d" % mid)
    pass


def on_publish_topic(mid, userdata):
    print("on_publish_topic mid:%d" % mid,"userdata",userdata)

def connectIOT(productKey,deviceName,deviceSecret):
    hostName="cn-shanghai"
    lk = linkkit.LinkKit(
    host_name=hostName,
    product_key=productKey,
    device_name=deviceName,
    device_secret=deviceSecret)


    lk.on_device_dynamic_register = on_device_dynamic_register
    lk.on_connect = on_connect
    lk.on_disconnect = on_disconnect
    lk.on_topic_message = on_topic_message

    lk.on_subscribe_topic = on_subscribe_topic
    lk.on_unsubscribe_topic = on_unsubscribe_topic
    lk.on_publish_topic = on_publish_topic
    lk.config_mqtt(secure="")

    lk.connect_async()
    lk.start_worker_loop()

    time.sleep(3)
    publish_version(lk,productKey,deviceName)
    subscribe_upgrade(lk,productKey,deviceName)
    publish_progress(lk,productKey,deviceName)

import time
def getDeviceList(path):
    deviceList=[]
    with open(path) as f:
        line = f.readline().strip()
        while len(line) > 0:
            deviceList.append(line)
            line = f.readline().strip()
    return deviceList

def printTestDevice2(info):
    #print(info)
    if len(info['GmtActive']) == 0:
        print(info['DeviceName'], info['GmtOnline'], 'Version:', 'xxxxxxxx_xxxxxx', 'OnLine:',
              'Y' if info['Status'] == 'ONLINE' else 'N', "Active:", 'Y' if len(info['GmtActive']) else 'N')
    else:
        print(info['DeviceName'], info['GmtOnline'], 'Version:', info['FirmwareVersion'], 'OnLine:',
              'Y' if info['Status'] == 'ONLINE' else 'N',
              "Active:", 'Y' if len(info['GmtActive']) else 'N')

if __name__=="__main__":
    deviceList = getDeviceList("manual_ota_devices.txt")
    for deviceName in deviceList:
        productKey = "a1hBht2FlUT"
        tool = OTA_Tools()
        info = tool.queryDeviceByName(productKey,deviceName)
        if info==0:
            break;
        deviceSecret = info['DeviceSecret']
        print("deviceSecret",deviceSecret,"Status:",info['Status'])
        if info['Status']=='OFFLINE':
            connectIOT(productKey,deviceName,deviceSecret)

    time.sleep(10)
    print("OK")