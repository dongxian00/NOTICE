from ali_ota_tool import OTA_Tools
import time
import subprocess
def getDeviceList(path):
    deviceList=[]
    with open(path) as f:
        line = f.readline().strip()
        while len(line) > 0:
            deviceList.append(line)
            line = f.readline().strip()
    return deviceList

if __name__=="__main__":
    tool = OTA_Tools()
    productkey="a1hBht2FlUT"
    deviceList=getDeviceList("devices.txt")
    while True:
        try:
            success = 0
            for deviceName in deviceList:
                info = tool.queryDeviceByName(productkey,deviceName)
                if info['FirmwareVersion'] == '20190920_000619':
                    success = success + 1
            rate = success/len(deviceList)
            mes = '自9月20日22点推送619版本给入户设备，截至当前OTA成功率为'+ str(success) + '/' + str(len(deviceList)) + '=' + str('%.2f%%' % (rate * 100))
            subprocess.call('curl -X POST \
                      https://rocket.bytedance.net/v2/larkatmembersingroup \
                      -F "msg="' + mes +' \
                      -F infotype=3 \
                      -F "member=liuhui.liuhuiqq" \
                      -F groupid=6725772050608161032 \
                      -F bottype=0', shell=True)
            time.sleep(3600*12)
        except:
            pass



