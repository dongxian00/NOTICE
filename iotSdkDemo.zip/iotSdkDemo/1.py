from aliyunsdkiot.request.v20180120 import QueryDeviceDetailRequest
from Common.ClientUtil import ClientUtil
import json,datetime
class OTA_Tools:
    clt = ClientUtil.createClient()
    def queryDeviceByName(self, productKey, deviceName):
        request = QueryDeviceDetailRequest.QueryDeviceDetailRequest()
        request.set_ProductKey(productKey)
        request.set_DeviceName(deviceName)
        result = str(self.clt.do_action_with_exception(request),'utf-8')
        result_json = json.JSONDecoder().decode(result)
        if result_json['Success']:
            return result_json['Data']
        else:
            print('queryDeviceByName failed , errorMessage=' + result_json['ErrorMessage'] + ', requestId=' + result_json['RequestId'])

    def getDeviceList(self,path):
        deviceList = []
        with open(path) as f:
            line = f.readline().strip()
            while len(line) > 0:
                deviceList.append(line)
                line = f.readline().strip()
        return deviceList
if __name__=="__main__":
    tool = OTA_Tools()
    deviceList = tool.getDeviceList("./drill_1")
    productkey="a1hBht2FlUT"
    start_time = datetime.datetime.strptime('2019-09-06 21:00:00', "%Y-%m-%d %H:%M:%S")
    for deviceName in deviceList:
        try:
            info = tool.queryDeviceByName(productkey,deviceName)
            if info['FirmwareVersion'] != '20190920_000619':
                print(deviceName, info['GmtOnline'], 'Version:', info['FirmwareVersion'], 'OnLine:','Y' if info['Status'] == 'ONLINE' else 'N', end='')
                GmtOnline = datetime.datetime.strptime(info['GmtOnline'], "%Y-%m-%d %H:%M:%S")
                if GmtOnline > start_time:
                    print('  用户在线时未升级成功，重点关注')
                else:
                    print('')
        except:
            print(deviceName+'设备未激活')

