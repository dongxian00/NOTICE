#!/usr/bin/python
# -*- coding: utf-8 -*-
from aliyunsdkcore import  client

class ClientUtil:
    @staticmethod
    def createClient():
        #阿里云账号
        accessKeyId = 'LTAIiOoq6G6XK0xH'
        accessKeySecret = 'XbO7qrFPnRuaW9c0kT24mzh1qgQtXV'
        regionId = 'cn-shanghai'
        clt = client.AcsClient(accessKeyId, accessKeySecret, regionId)
        return clt