#!/usr/bin/python
# -*- coding: utf-8 -*-
# @Time     : 2019-09-18 16:04 
# @Author   : 董贤biubiu!!
# @FileName : 2.py

lines = open('./010#漏电流43（20190918）','r').readlines()
i = 0
file1 = open('./temperature_new','w')
for line in lines:
    i = i + 1
    if i % 2 != 0:
        file1.write(lines[i-1].strip() + ' ' + lines[i])
