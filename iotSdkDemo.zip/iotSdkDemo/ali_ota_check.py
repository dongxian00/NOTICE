from ali_ota_tool import OTA_Tools
import os
def getDeviceList(path):
    deviceList=[]
    with open(path) as f:
        line = f.readline().strip()
        while len(line) > 0:
            deviceList.append(line)
            line = f.readline().strip()
    return deviceList

if __name__=="__main__":
    #test_queryDevice()
    tool = OTA_Tools()
    productkey="a1hBht2FlUT"
    deviceList=getDeviceList("devices.txt")
    if len(deviceList)==0:
        print("No Device")
        exit(1)
    for deviceName in  deviceList:
        info = tool.queryDeviceByName(productkey,deviceName)
        if len(info['GmtActive'])==0:
            print(deviceName,'Version:','xxxxxxxx_xxxxxx','OnLine:','Y' if info['Status']=='ONLINE' else 'N',"Active:", 'Y' if len(info['GmtActive']) else 'N')
        else:
            print(deviceName, 'Version:', info['FirmwareVersion'], 'OnLine:', 'Y' if info['Status'] == 'ONLINE' else 'N',
                  "Active:", 'Y' if len(info['GmtActive']) else 'N')

